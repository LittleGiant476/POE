/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poe;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author ecmat
 */
public class POE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          //Scanner scan = new Scanner(System.in);
   
  //Declaring Variables
  
  String user; 
  String pass;
  String firstName; 
  String lastName;
  
   
  
  ///////////////////////////////////////////////////////////////////////////////
  
  
  // System.out.println(" Enter your First Name: ");
  firstName = JOptionPane.showInputDialog(null,"Your First Name?");
  
  //System.out.println("Enter your Surname: ");
  lastName = JOptionPane.showInputDialog(null,"Your Last Name?");  
  
  //System.out.println(" Enter your username: ");
  user = JOptionPane.showInputDialog(null,"Your Username you would like to use?");
  
  //System.out.println("Enter your password: ");
  pass = JOptionPane.showInputDialog(null,"Your Password you would like to use?");   
        
 
  
if((user.length() < 6) == true)
        {
        if(CheckUser(user)){
        
        //System.out.println("Username successfully captures");
        JOptionPane.showMessageDialog(null,"Username successfully captured");       
        }
        }
else{
       //System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters long");
       JOptionPane.showMessageDialog(null,"Username is not correctly formatted");

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////

        Pattern rPattern = Pattern.compile("^[a-zA-Z0-9_-]{5,15}$");
        Matcher rMatcher = rPattern.matcher(user);
        
        if(rMatcher.matches()){
            
           //System.out.println("Password valid");   
           JOptionPane.showMessageDialog(null,"Password successfully captured");
        }
        else{      
    //System.out.println("Password incorrect");
            JOptionPane.showMessageDialog(null,"Password not successfully captured");
        }
//////////////////////////////////////////////////////////////////////////////////////

        if(pass.length() > 7)
        {
        if(checkPass(pass)){
          
        
        }
       // else{
            
        //}
        }
        
        else
        {    
            System.out.println("Too small");
            
        }

 /////////////////////////////////////////////////////////////////////////////////// 
  
/* if(PasswordCallOut(pass)== true && (valUserName(user)== true)){

System.out.println("Welcome " + firstName +", "+ lastName +" its great to see you again" );
    
}
else{
System.out.println("Username or password incorrect, please try again");    
} 
*/  
////////////////////////////////////////////////////////////////////////////////  
//////////////////////////////////////////////////////////////////////////////// 
////////////////////////////////////////////////////////////////////////////////  
  
if(PasswordCallOut(pass)== true && (valUserName(user)== true)){ 

    String Response;
        Response = JOptionPane.showInputDialog(null, " Please select an option" 
                                                                            + "\n 1. Add Task" 
                                                                            + "\n 2. Show Report"  
                                                                            + "\n 3. Quit",  "EasyKanBan",JOptionPane.QUESTION_MESSAGE);
        int i= Integer.parseInt(Response);
        //int l = Integer.parseInt(taskNumber); // could not get this parsing to work 
       while(i<=2){
       if (i < 2)
         {
             for (int j = 0; j < 1; j++) {
                 
            int taskNumber = Integer.parseInt(JOptionPane.showInputDialog(null,"How many task would you like to add?"));
                    for( int k = 1; k <= taskNumber; k++){
                        
            /////////////////////////////////////////////////////////////////////////
            
            String DeveloperName = JOptionPane.showInputDialog(null,"What is your name?");
   
            String DeveloperSurname = JOptionPane.showInputDialog(null,"What is your surname?");
              
            String taskName = JOptionPane.showInputDialog(null,"What is the name of the task?");
            
            String taskDescription = JOptionPane.showInputDialog(null,"What is the description of the task?");
               
            String taskDoing = JOptionPane.showInputDialog(null,"How many tasks would you like to add?");
           
            int hours = Integer.parseInt(JOptionPane.showInputDialog(null,"How long will it take?"));
            
            /////////////////////////////////////////////////////////////////////////
            if(taskDescription.length() < 51){
               String taskID = taskName.substring(0, 2) + ":" + k + ":" + DeveloperName.substring(DeveloperName.length()-3);
               
              JOptionPane.showMessageDialog(null,taskID.toString());
            taskID = taskID.toUpperCase(); 
            
            JOptionPane.showMessageDialog(null,"First Name: " +DeveloperName + " | " + "Last Name: " +DeveloperSurname +
                    "\n | "+ "Task Name: " +taskName + " | " + "Status: " + taskDoing +  " | " + "Hours: " + hours);
                        }
                else{
            JOptionPane.showMessageDialog(null,"Description is more than 50 characters");    
                    }
                }
            } 
        }
       else {
    String [] arrNames = {"Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"};
    String [] arrTaskNames = {"Create Login", "Create Features", "Create Reports", "Add Arrays"};
    int [] arrMarks = {5, 8, 2, 11};
    String [] arrStatus = {"To Do", "Doing", "Done", "To Do"};   
   

   
    JOptionPane.showMessageDialog(null,"The Tasks are : ");
    
    for(int j = 0; j < arrTaskNames.length && j < arrNames.length; j ++){
        
     JOptionPane.showMessageDialog(null,arrNames[j] + "| Duration of " + arrMarks[j] + " Hours | Task Name " + arrTaskNames[j] +
             "\n" + "| Current Status " + arrStatus[j] + "| Task Number " + (j +1));
      
     System.out.println(" ");
    }

    System.out.println(" ");
    JOptionPane.showMessageDialog(null,"The longest task is: ");
    
    int himark = arrMarks[0];
    String hiname = arrNames[0];
    
    for(int j = 0; j <arrMarks.length; j++)
    {
        
        if(arrMarks[j] > himark)
        {
        himark = arrMarks[j];
        hiname = arrNames[j];
        }    
    }
    
    System.out.println(" ");
    JOptionPane.showMessageDialog(null,"The Name of the person with the longest task is : " + hiname + 
            "\n" + "The task duration is: " + himark + " Hours");
    
    JOptionPane.showMessageDialog(null,"Searching using Employee name");
    
    String N = JOptionPane.showInputDialog(null,"Enter the name of ther employee to search: ");
    
    boolean flag = true;
    
    for(int j = 0; j < arrMarks.length; j++)
    {
     
      if (arrNames[j].equalsIgnoreCase(N)){
        
          flag = true;
          JOptionPane.showMessageDialog(null,"The report for " + arrNames[j] +
                  "\n " + arrMarks[j] + " Hours, and the task is: " + arrTaskNames[j]);
              }  
        
    }
    
    if(flag == false){
        JOptionPane.showMessageDialog(null,"The Name was not found");
    }
    
    System.out.println(" ");
    JOptionPane.showMessageDialog(null,"Searching using Task name");
    
    String O = JOptionPane.showInputDialog(null,"Enter the Task: ");
    
    boolean node = true;
    
    for(int j = 0; j < arrMarks.length; j++)
    {
     
      if (arrTaskNames[j].equalsIgnoreCase(O)){
        
          node = true;
          JOptionPane.showMessageDialog(null,"The task is: " + arrNames[j] + ", " + arrTaskNames[j]);
              }  
        
    }
    
    if(node == false){
        JOptionPane.showMessageDialog(null,"The Name was not found");
    }
    
    String p = JOptionPane.showInputDialog(null, "What task would you like to remove?");
    
    
    int indexless = 0;
    String[] lessTasks = new String[arrTaskNames.length-1];
    for(int j = 0; j < (arrTaskNames.length-1); j++){
     
        if(!arrTaskNames[j].equalsIgnoreCase(p))
    lessTasks[indexless]=arrTaskNames[j];
    indexless++;
    
    JOptionPane.showMessageDialog(null,arrNames[j] + " | Task: " +lessTasks[j] +  " | Hours:  " +
            "\n"+ arrMarks[j] +  " | Status:" +arrStatus[j] );
    }
    JOptionPane.showMessageDialog(null,"Task " + p +" removed");
       }
         Response = JOptionPane.showInputDialog(null," Please select an option : 1 Addtask, 2 Show report , 3 Quit");
         i= Integer.parseInt(Response);
         
    } 
      
    }
        
} 
   
  
/*public static boolean returnLoginstatus(String pass, String user, String firstName, String lastName){    

if(PasswordCallOut(pass)== true && (valUserName(user)== true)){

System.out.println("Welcome " + firstName +", "+ lastName +" its great to see you again" );
return true;    
}
else{
System.out.println("Username or password incorrect, please try again");
return false;    
}    
*/


 public static boolean valPassword(String pass){
    
        if(pass.length() > 7)
        {
        if(checkPass(pass)){
        return true;  
        
        }
        else{
            return false;
        }
        }
        
        else
        {    
            System.out.println("Too small");
            return false;
        }
    }
 
public static boolean valUserName(String user){
    
        if((user.length() < 6) == true)
        {
        if(CheckUser(user)){
        
        System.out.println("Username successfully captures");
        return true;        
        }
        }
        System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters long");
       return false; 
}

public static boolean CheckUser(String user)
    {    
        Pattern rPattern = Pattern.compile("^[a-zA-Z0-9_-]{5,15}$");
        Matcher rMatcher = rPattern.matcher(user);
        
        if(rMatcher.matches()){
            
           System.out.println("Password valid");
         return true;   
        }
        else{
             
    System.out.println("Password incorrect");
        return false;

        }
    }

    public static boolean checkPass(String pass)
    {
            //1 Capital Letter
            //1 Lowercase Letter
            //1 Number
            //1 special character will be in a second method because of simplicity
        boolean hasNum = false;
        boolean hasCap = false;
        boolean hasLow = false;
        char c;
        
        for (int i =0; i < pass.length(); i++)
        {
            
        c = pass.charAt(i);
        if(Character.isDigit(c))
        {
            hasNum = true;
        }
        else if(Character.isUpperCase(c))
        {
            hasCap = true;
        }
        else if(Character.isLowerCase(c))
        {
            hasLow = true;
        }
        if(hasNum && hasCap && hasLow){
            return true;
        }
        
        }
    return false;
    }
            //Special character requirment
    public static boolean hasSpecialCharacter(String pass)
    {    
        Pattern sPattern = Pattern.compile("[a-zA-Z0-9]*");
        Matcher sMatcher = sPattern.matcher(pass);
        
        if(!sMatcher.matches()){
            
            return true;
        }
        else{
         System.out.println("No special character found");    
    return false;
   
    }
        
    }
    
 public static boolean PasswordCallOut(String pass){    
    
    if(checkPass(pass) && hasSpecialCharacter(pass) == true ) {    
    
    System.out.println("Password successfully captured");
    return true; 
    }
    
    else{
        
    System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special charcter");
    return false;
    }
    }

}  